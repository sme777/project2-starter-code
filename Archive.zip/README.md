# project2-starter-code

### Michael Khachatrian and Samson Petrosyan
Skeleton code for CS161 Project 2
